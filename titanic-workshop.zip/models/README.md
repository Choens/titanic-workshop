README - Models

- This folder is a nice place to put your models.
- That is all.
